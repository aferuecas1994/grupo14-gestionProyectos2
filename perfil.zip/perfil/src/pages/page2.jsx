import React from 'react';

const Page2 = () => {
  return <div>Pagina 2</div>;
};

export default Page2;